The outputs of training process could be obtained here.
